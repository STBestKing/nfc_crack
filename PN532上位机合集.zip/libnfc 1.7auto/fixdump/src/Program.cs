﻿using System;
using System.IO;

namespace fixdump
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 1)
            {
                string strFilePath = args[0];
                if (File.Exists(strFilePath))
                {
                    FileStream fsA = new FileStream(strFilePath, FileMode.Open);

                    if (fsA.Length != 1024)
                    {
                        Console.WriteLine("文件不匹配");
                    }
                    else
                    {
                        byte[] byteArray = new byte[3072];
                        fsA.Seek(1024, SeekOrigin.Current);
                        fsA.Write(byteArray, 0, byteArray.Length);
                        fsA.Close();
                        Console.WriteLine("修复OK:  " + strFilePath);
                    }
                }
                else
                {
                    Console.WriteLine("无法找到文件:   " + strFilePath);
                }
            }
            else
            {
                Console.WriteLine("---修复mfocGUI V29转储文件大小1k为4k---");
                Console.WriteLine("eg: fixdump.exe c:\\1k.dump");
            }

        }
    }
}
