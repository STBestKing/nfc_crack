fixdump程序是用于修复mfocgui等等的Windows平台M1卡破解程序导出的dump文件的工具，默认这些工具导出的dump文件只有1k且无法直接打开，用这个工具修复后就会变成4k，用WinHex之类的十六进制编辑器打开就可以正常查看内容。

工具是命令行操作的，语法如下
fixdump.exe <dump文件路径>
例:
fixdump 123.dump
fixdump C:\123.dump
修复后会直接覆盖源文件

程序需要.NET Framework 4的支持，如果出现程序无法使用请安装.NET Framework 4

Firefly风物 http://bobylive.com